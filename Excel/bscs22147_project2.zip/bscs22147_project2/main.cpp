#include<iostream>
#include"Excel.h"
#include<SFML/Graphics.hpp>
using namespace sf;
using namespace std;

int main()
{
	Excel* excl = new Excel();
	
	excl->LaunchExcel();
    
    return 0;




}